<?php
    $policyPages = getContent('policy_pages.element', false, null, true);
    $socialIcons = getContent('social_icon.element', orderById: true);
    $language = App\Models\Language::all();
    $selectedLang = $language->where('code', session('lang'))->first();

?>

<footer class="footer py-100">
    <div class="custom--container">
        <!-- Footer Top Section -->
        <div class="footer-top">
            <div class="footer-top-left">
                <a class="footer-logo" href="<?php echo e(route('home')); ?>">
                    <img src="<?php echo e(siteLogo()); ?>" alt="<?php echo app('translator')->get('Logo'); ?>">
                </a>
                <p class="footer-tagline"><?php echo app('translator')->get('Empowering learners worldwide with quality education and knowledge sharing'); ?></p>
            </div>

            <div class="footer-links-group">
                <div class="footer-column">
                    <h4 class="footer-column-title"><?php echo app('translator')->get('Quick Links'); ?></h4>
                    <ul class="footer-menu">
                        <li class="footer-menu-item">
                            <a class="footer-menu-link" href="<?php echo e(route('home')); ?>"><?php echo app('translator')->get('Home'); ?></a>
                        </li>
                        <li class="footer-menu-item">
                            <a class="footer-menu-link" href="<?php echo e(route('courses')); ?>"><?php echo app('translator')->get('Courses'); ?></a>
                        </li>
                        <li class="footer-menu-item">
                            <a class="footer-menu-link" href="<?php echo e(route('contact')); ?>"><?php echo app('translator')->get('Contact'); ?></a>
                        </li>
                        <?php if(auth()->guard()->guest()): ?>
                            <li class="footer-menu-item">
                                <a class="footer-menu-link" href="<?php echo e(route('user.login')); ?>"><?php echo app('translator')->get('Login'); ?></a>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>

                <?php if($policyPages->count()): ?>
                    <div class="footer-column">
                        <h4 class="footer-column-title"><?php echo app('translator')->get('Legal'); ?></h4>
                        <ul class="footer-menu">
                            <?php $__currentLoopData = $policyPages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $policy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="footer-menu-item">
                                    <a class="footer-menu-link" href="<?php echo e(route('policy.pages', [slug($policy->data_values->title), $policy->id])); ?>">
                                        <?php echo e(__(@$policy->data_values->title)); ?>

                                    </a>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <?php if(gs()->multi_language): ?>
                    <div class="footer-column">
                        <h4 class="footer-column-title"><?php echo app('translator')->get('Language'); ?></h4>
                        <div class="dropdown-lang dropdown mt-0 d-block footer-lang">
                            <a href="#" class="language-btn dropdown-toggle" data-bs-toggle="dropdown"
                                aria-expanded="false">
                                <img class="flag"
                                    src="<?php echo e(getImage(getFilePath('language') . '/' . @$selectedLang->image, getFileSize('language'))); ?>"
                                    alt="language">
                                <span class="language-text"><?php echo e(@$selectedLang->name); ?></span>
                            </a>
                            <ul class="dropdown-menu">
                                <?php $__currentLoopData = $language; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><a href="<?php echo e(route('lang', $lang->code)); ?>"><img class="flag"
                                                src="<?php echo e(getImage(getFilePath('language') . '/' . @$lang->image, getFileSize('language'))); ?>"
                                                alt="<?php echo app('translator')->get('image'); ?>">
                                        <?php echo e(@$lang->name); ?></a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                <?php endif; ?>
            </div>

            <div class="footer-top-right">
                <h4 class="footer-column-title"><?php echo app('translator')->get('Follow Us'); ?></h4>
                <ul class="footer-social">
                    <?php $__currentLoopData = $socialIcons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $socialIcon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="footer-social-item">
                            <a class="footer-social-link" href="<?php echo e($socialIcon->data_values->url); ?>" target="_blank" title="Follow">
                                <?php echo $socialIcon->data_values->social_icon ?>
                            </a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>

        <!-- Footer Bottom Section -->
        <div class="footer-bottom">
            <p class="footer-rights-text">
                &copy; <?php echo e(date('Y')); ?> <a class="text--base" href="<?php echo e(route('home')); ?>"><?php echo e(__(gs()->site_name)); ?></a>. <?php echo app('translator')->get('All Rights Reserved'); ?>. <span class="footer-credit"><?php echo app('translator')->get('Crafted with'); ?> <i class="fas fa-heart"></i> <?php echo app('translator')->get('for learning excellence'); ?></span>
            </p>
        </div>
    </div>
</footer>

<?php /**PATH C:\xampp\htdocs\nekxrlms\core\resources\views/templates/basic/partials/footer.blade.php ENDPATH**/ ?>