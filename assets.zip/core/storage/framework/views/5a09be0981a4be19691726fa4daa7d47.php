<?php
    $subscribe = getContent('subscribe.content', true);
?>

<section class="subscribe-now pt-60 pb-120">
    <div class="container">
        <div class="subscribe-now-row">
            <div class="subscribe-now-col">
                <div class="subscribe-now-content">
                    <h3 class="subscribe-now-title"><?php echo e(__(@$subscribe->data_values->title)); ?></h3>

                    <p class="subscribe-now-description"><?php echo e(__(@$subscribe->data_values->subtitle)); ?></p>

                    <form class="subscribe-now-form" id="subscribe">
                        <?php echo csrf_field(); ?>
                        <input class="subscribe-now-form-input" type="email" name="email" id="email" placeholder="<?php echo app('translator')->get('Enter your email'); ?>" required>
                        <button class="subscribe-now-form-btn btn btn--base" type="submit"><?php echo app('translator')->get('Subscribe'); ?></button>
                    </form>
                </div>
            </div>

            <div class="subscribe-now-col">
                <img class="subscribe-now-thumb" src="<?php echo e(frontendImage('subscribe', @$subscribe->data_values->image, '640x550')); ?>" alt="<?php echo app('translator')->get('Subscribe now'); ?>">
            </div>
        </div>
    </div>
</section>

<?php $__env->startPush('script'); ?>
    <script>
        (function($) {
            "use strict";
            $('#subscribe').on('submit', function(e) {
                e.preventDefault();
                var data = $('#subscribe').serialize();
                $.ajax({
                    type: "POST",
                    url: "<?php echo e(route('subscribe')); ?>",
                    data: data,
                    success: function(response) {
                        if (response.status == 'success') {
                            notify('success', response.message);
                            $('#email').val('');
                        } else {
                            notify('error', response.message);
                        }
                    }
                });
            });
        })(jQuery);
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\xampp\htdocs\nekxrlms\core\resources\views/templates/basic/sections/subscribe.blade.php ENDPATH**/ ?>