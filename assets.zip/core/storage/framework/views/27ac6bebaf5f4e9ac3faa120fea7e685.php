<?php $__env->startSection('panel'); ?>
    <!-- Main CSS -->
    <link rel="stylesheet" href="<?php echo e(asset($activeTemplateTrue . 'css/main.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset($activeTemplateTrue.'css/color.php')); ?>?color=<?php echo e(gs('base_color')); ?>">

    <div class="preloader">
        <div class="loader-p"></div>
    </div>

    <a class="scroll-top"><i class="fas fa-angle-double-up"></i></a>
    
    <?php
    $authRoute = request()->routeIs('user.login') || request()->routeIs('user.register') || request()->routeIs('maintenance');
    ?>

    <?php if(!$authRoute): ?>
    <?php echo $__env->make($activeTemplate . 'partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

    <?php echo $__env->yieldContent('content'); ?>

    <?php if(!$authRoute): ?>
    <?php echo $__env->make($activeTemplate . 'partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make($activeTemplate . 'layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nekxrlms\core\resources\views/templates/basic/layouts/frontend.blade.php ENDPATH**/ ?>