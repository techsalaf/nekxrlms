<?php
    $sponsor = getContent('sponsor.content', true);
    $sponsors = getContent('sponsor.element', orderById: true);
?>

<?php if($sponsors->count()): ?>
    <section class="used-by py-60">
        <div class="custom--container">
            <h6 class="used-by-title"><?php echo e(__(@$sponsor->data_values->title)); ?></h6>
            <div class="used-by-logos">
                <?php $__currentLoopData = $sponsors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sponsor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <img src="<?php echo e(frontendImage('sponsor', @$sponsor->data_values->sponsor_image, '150x50')); ?>" alt="<?php echo app('translator')->get('Image'); ?>">
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\nekxrlms\core\resources\views/templates/basic/sections/sponsor.blade.php ENDPATH**/ ?>