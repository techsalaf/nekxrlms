<?php
    $testimonial = getContent('testimonial.content', true);
    $testimonials = getContent('testimonial.element');
?>

<section class="student-reviews py-60">
    <div class="container">

        <h3 class="student-reviews-title"><?php echo e(__(@$testimonial->data_values->title)); ?></h3>

        <div class="row g-4">
            <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6 col-lg-4">
                    <div class="review-card">
                        <div class="review-card-ratings">
                            <?php
                                echo ratingStar(@$testimonial->data_values->rating);
                            ?>
                        </div>

                        <p class="review-card-text"><?php echo e(__(@$testimonial->data_values->review)); ?></p>

                        <div class="review-card-student">
                            <img class="review-card-student-avatar" src="<?php echo e(frontendImage('testimonial', $testimonial->data_values->image, '50x50')); ?>" alt="<?php echo app('translator')->get('image'); ?>">

                            <div class="review-card-student-info">
                                <strong class="review-card-student-name"><?php echo e(__(@$testimonial->data_values->name)); ?></strong>

                                <span class="review-card-student-position"><?php echo e(__(@$testimonial->data_values->designation)); ?></span>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php /**PATH C:\xampp\htdocs\nekxrlms\core\resources\views/templates/basic/sections/testimonial.blade.php ENDPATH**/ ?>