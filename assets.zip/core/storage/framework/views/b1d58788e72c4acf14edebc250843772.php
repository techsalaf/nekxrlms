<?php
    $courseInfo = getContent('course_info.content', true);
    $courseInfos = getContent('course_info.element', orderById: true);
?>

<section class="live-course-info pt-120 pb-60">
    <div class="custom--container">
        <div class="row g-4">
            <div class="col-md-6">
                <div class="live-course-info-content">
                    <h3 class="live-course-info-title"><?php echo e(__($courseInfo->data_values->title)); ?></h3>
                    <p class="live-course-info-description"><?php echo e(__($courseInfo->data_values->subtitle)); ?></p>
                    <a class="live-course-info-lightbox" href="<?php echo e($courseInfo->data_values->video_link); ?>">
                        <img src="<?php echo e(frontendImage('course_info', $courseInfo->data_values->video_thumb,'500x330')); ?>" alt="Live Course Info Lightbox Thumb">
                    </a>
                </div>
            </div>

            <div class="col-md-6">
                <ul class="live-course-info-keypoints">
                    <?php $__currentLoopData = $courseInfos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $courseInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="live-course-info-keypoints-item">
                        <div class="live-course-info-keypoints-icon">
                            <img src="<?php echo e(frontendImage('course_info', @$courseInfo->data_values->image,'50x50')); ?>" alt="<?php echo app('translator')->get('Course Info'); ?>">
                        </div>

                        <div class="live-course-info-keypoints-content">
                            <h6 class="live-course-info-keypoints-title">
                                <?php echo e(__(@$courseInfo->data_values->title)); ?>

                            </h6>

                            <p class="live-course-info-keypoints-description">
                                <?php echo e(__(@$courseInfo->data_values->subtitle)); ?>

                            </p>
                        </div>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
    </div>
</section>
<?php /**PATH C:\xampp\htdocs\nekxrlms\core\resources\views/templates/basic/sections/course_info.blade.php ENDPATH**/ ?>