<?php
    $categories = App\Models\Category::active()->orderBy('name')->get();
?>

<header class="header">
    <div class="custom--container">
        <nav class="navbar navbar-expand-lg header-navbar">
            <a class="navbar-brand" href="<?php echo e(route('home')); ?>">
                <img src="<?php echo e(siteLogo()); ?>" alt="<?php echo app('translator')->get('Logo'); ?>">
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#header-navbar-collapse" aria-expanded="false">
                <i class="fas fa-bars"></i>
            </button>
            <div id="header-navbar-collapse" class="collapse navbar-collapse">
                <ul class="navbar-nav nav-menu ms-auto align-items-lg-center">
                    <li class="nav-item <?php echo e(menuActive('home')); ?>">
                        <a class="nav-link" href="<?php echo e(route('home')); ?>"><?php echo app('translator')->get('Home'); ?></a>
                    </li>
                    <li class="nav-item <?php echo e(menuActive(['courses', 'course.details', 'course.lesson'])); ?>">
                        <a class="nav-link" href="<?php echo e(route('courses')); ?>"><?php echo app('translator')->get('Courses'); ?></a>
                    </li>
                    <?php if($categories->count()): ?>
                        <li class="nav-item dropdown <?php echo e(menuActive('category.course')); ?>">
                            <a class="nav-link" href="javascript:void(0)" role="button" data-bs-toggle="dropdown"
                                aria-expanded="false">
                                <?php echo app('translator')->get('Categories'); ?> <span class="nav-item__icon"><i class="las la-angle-down"></i></span>
                            </a>
                            <ul class="dropdown-menu">
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="dropdown-menu__list">
                                        <a class="dropdown-item dropdown-menu__link"
                                            href="<?php echo e(route('category.course', [slug($category->name), $category->id])); ?>"><?php echo e(__($category->name)); ?></a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </li>
                    <?php endif; ?>
                    <?php
                        $pages = App\Models\Page::where('tempname', $activeTemplate)->where('is_default', 0)->get();
                    ?>
                    <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(menuActive('pages', null, $data->slug)); ?>"
                                href="<?php echo e(route('pages', [$data->slug])); ?>"><?php echo e(__($data->name)); ?></a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <li class="nav-item <?php echo e(menuActive('contact')); ?>">
                        <a class="nav-link" href="<?php echo e(route('contact')); ?>"><?php echo app('translator')->get('Contact'); ?></a>
                    </li>
                </ul>
                <div class="navbar-buttons">
                    <?php if(auth()->guard()->guest()): ?>
                        <a class="btn btn--rounded btn--light-two navbar-login-btn" href="<?php echo e(route('user.login')); ?>"
                            role="button">
                            <div class="las la-user-alt"></div>
                            <span><?php echo app('translator')->get('Login'); ?></span>
                        </a>
                        <a class="btn btn--rounded btn--base navbar-enroll-btn" href="<?php echo e(route('user.register')); ?>"
                            role="button">
                            <i class="las la-plus-circle"></i>
                            <?php echo app('translator')->get('Register'); ?>
                        </a>
                    <?php else: ?>
                        <a class="btn btn--rounded btn--light-two navbar-login-btn" href="<?php echo e(route('user.home')); ?>"
                            role="button">
                            <div class="las la-user-alt"></div>
                            <span><?php echo app('translator')->get('Dashboard'); ?></span>
                        </a>
                        <a class="btn btn--rounded btn--base navbar-enroll-btn" href="<?php echo e(route('user.logout')); ?>"
                            role="button">
                            <i class="las la-sign-out-alt"></i>
                            <?php echo app('translator')->get('Logout'); ?>
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </nav>
    </div>
</header>
<?php /**PATH C:\xampp\htdocs\nekxrlms\core\resources\views/templates/basic/partials/header.blade.php ENDPATH**/ ?>