<?php

return [
    'course.details'=>false
];
