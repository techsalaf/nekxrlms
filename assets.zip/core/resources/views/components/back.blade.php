@props(['route' => ''])

<a href="{{ $route }}" class="btn btn-sm btn-outline--dark">
    <i class="la la-undo"></i> @lang('Back')
</a>
