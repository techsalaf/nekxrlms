<div class="card custom--card mt-5">
    <div class="card-body p-0">
        <div class="card-empty">
            <div class="empty-thumb">
                <img src="{{ getImage('assets/images/empty_list.png') }}" alt="@lang('image')">
            </div>
            <p class="text-center">{{ __($data) }}</p>
        </div>
    </div>
</div>
